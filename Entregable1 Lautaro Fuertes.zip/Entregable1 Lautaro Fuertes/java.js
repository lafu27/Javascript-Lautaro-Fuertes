const libro1 = { nombre: "El Principito", precio: 1500, stock: 5 };
const libro2 = { nombre: "Cien Años de Soledad", precio: 2000, stock: 3 };
const libro3 = { nombre: "1984", precio: 1800, stock: 4 };
const libro4 = { nombre: "Rayuela", precio: 1600, stock: 2 };
const libros = [libro1, libro2, libro3, libro4];
let carrito = [];
let total = 0;

function mostrarCatalogo() {
  let mensaje = "Catálogo de Libros:\n";
  for (let i = 0; i < libros.length; i++) {
    mensaje += (i + 1) + ". " + libros[i].nombre + " - $" + libros[i].precio + " (Stock: " + libros[i].stock + ")\n";
  }
  mensaje += "\nElige un libro ingresando el número correspondiente (o escribe 'salir' para terminar):";

  let seleccion = prompt(mensaje);

  if (seleccion === "salir") {
    mostrarResumen();
  } else {
    let indice = parseInt(seleccion) - 1;
    if (indice >= 0 && indice < libros.length) {
      procesarCompra(indice);
    } else {
      alert("Selección no válida, intenta nuevamente.");
      mostrarCatalogo();
    }
  }
}

function procesarCompra(indice) {
  if (libros[indice].stock > 0) {
    libros[indice].stock -= 1;
    carrito.push(libros[indice].nombre);
    total += libros[indice].precio;
    alert("Has agregado '" + libros[indice].nombre + "' a tu carrito.");
  } else {
    alert("Lo sentimos, '" + libros[indice].nombre + "' está agotado.");
  }
  mostrarCatalogo();
}

function mostrarResumen() {
  if (carrito.length === 0) {
    alert("No has comprado ningún libro.");
  } else {
    let mensaje = "Resumen de tu compra:\n";
    for (let i = 0; i < carrito.length; i++) {
      mensaje += (i + 1) + ". " + carrito[i] + "\n";
    }
    mensaje += "\nTotal a pagar: $" + total;
    alert(mensaje);
  }
}

mostrarCatalogo();